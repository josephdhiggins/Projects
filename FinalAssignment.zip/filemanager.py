#https://repl.it/@JosephDHiggins/FinalAssignment#filemanager.py
#https://repl.it/join/hrklwlxj-josephdhiggins

class FileManager():#creating a class called FileManager

  def __init__(self, filename):#using the __init__ function to assign values for a filename
    self.__filename = filename #used for assigning a variable to a filename

  def get_line_number(self, num): #creating a method that will be used to retrieve a line number from the file.
    word_file = open(self.__filename) #opening the file to read using the variable word_file
    counter = 0 #setting a counter to 0 so that it can later be used to be incremented so we know what line number we are on
    lines = [] #creating a list that will store the lines from the file.
    for line in word_file: #creating a for loop that runs through the lines of the file
      lines.append(line) #for every line the loop runs through, that line will be appended to the list
      counter+=1 #incrementing the counter
    
    if num >= counter or num < 0: #if the number inputted by the user is less than 1 and is greater than the amount of lines in the file it will return -1
      return -1 #returning -1

    else: # if the number inputted by the user is within the amount of lines in the file then it will return that line
      return lines[num] #returning the number of the line that the user inputted
      
  def get_botfilemanager(self): #creating a method to get the file
    return self.set.botfilemanager() #returning the file that was opened in the set_botfilemanager method 

  def set_botfilemanager(self): #creating a method that sets the file we want to return
    file = open(self.__filename) #opening the file to read using a variable 'file'
    return file #returning that variable

  def read_lines(self): #creating a method that read all of the lines of the file
    file_1 = open(self.__filename) #opening the correct file 
    Lines = file_1.readlines() #creating a variable that reads through the lines of the file.
    string = ""
    for line in Lines: #creating a for loop that runs through the lines of the file
      String = string.join(Lines)
      return String
      #for every line that the loop runs through, it prints the Line 

  def read_line_range(self, ran): #creating a method that asks the user to enter a start value and an end value and the program then prints the lines within the range chosen by the user
    s = ""
    file2 = open(self.__filename) #opening the correct file
    Lines = file2.readlines() #creating a variable that reads through the lines of the file 
    Range = Lines[ran[0]-1:ran[1]] #setting the range of lines to run through by using the variable ran. ran is a list of values that were inputted by the user, the first number is the start value and the second number is the end value
    if ran[0] > ran[1]: #if the starting value is greater than the end value then the program will not run and the user will be displayed with the following message
      print("================\n ================\n ================\n  ()\n -[]-\n  /\  \nThe first number you entered was higher than the second number you entered.")
    elif ran[0] < 1: #if the start value is less than 1 then the program will not run and the user will be displayed with the following message
      print("================\n ================\n ================\n  ()\n -[]-\n  /\  \nThe first number you entered is out of range") #this message informs the user that the starting value was out of range
    elif ran[1] > 9: #if the ending value is greater than 9 then the program will not run and the user will be displayed with the following message.
      print("================\n ================\n ================\n  ()\n -[]-\n  /\  \nTHE SECOND NUMBER YOU ENTERED WAS OUT OF RANGE") #the user is informed that the ending value was out of range
    else: #if none of these conditions were met and the input was correct then the following will be printed
      String = s.join(Range) 
      file2.close()
      return String

    

class BotFileManager(FileManager): #creating a new child class that inherits the FileManager class

  def __init__(self, filename): #using the __init__ function to assign values for a filename
    super().__init__(filename) #inheriting the filename from the Parent Class
    self.__filename = filename
    self.length = 0
    file = open(self.__filename)
    for line in file:
      self.length += 1
    file.close()

  def all_words(self): #creating a method that prints all the words in a dictionary. the first word is a key, which the user has to guess and the clues are stored in a list as the value of the dictionary.
    self.dictionary1 = {}
    #print("================\n ================\n ================\n  ()\n -[]-\n  /\  \nThese are all the words in a dictionary. The first word is a key, which the user has to guess and the clues are stored in a list as the value of the dictionary.") #informing the user of what this method is doing
    Lines = self.read_lines()
    newL = Lines.split("\n")
    counter = 0
    while counter < self.length:
      x = newL[counter]
      y = x.split(",")
      self.dictionary1[y[0]] = y[1:]
      counter += 1
    return self.dictionary1

  def dictionary_from_range(self, ran):
    Range = self.read_line_range(ran) #inheriting the read_line_range into this method as both methods have similar requirements
    NewL = (list(Range.split("\n")))
    fixed = [x for x in NewL if x!='']  # Fixed List

    key_word = []
    clues = []

    for value in fixed:
      a = (value.split(","))
      key_word.append(a[0])
      clues.append(a[1:])

    result = dict(zip(key_word, clues))
    return result

  def line_as_dictionary(self, num):
    lines = self.get_line_number(num)
    key_word = lines.split(",")[0]#splitting the rest of the words from the first word and assigning them to a variable called clues
    clues = lines.split(",")[1:]#splitting the rest of the words from the first word and assigning them to a variable called clues
    dictionary = {key_word: clues} #creating a dictionary that stores the key_word as the key and the clues as the values of the dictionary
    return dictionary #returning the dictionary

  def new_words(self): # creating new word method
    self.dictionary1 = {} #creating an empty dictionary
    ran = [] #creating an empty list
    start_number = int(input("Enter a number between 1 and 5: ")) #asking the user to enter a starting number that will set the new dictionary's starting line as this number
    end_number = int(input("Enter a number between 5 and 9: ")) #asking the user to enter a ending number that will set the new dictionary's final line as this number
    ran.append(int(start_number)) #appending the starting number to the list so that the ran variable knows where to start the dictionary
    ran.append(int(end_number)) #appending the ending number to the list so that the ran variable knows where to stop the dictionary
    String = self.read_line_range(ran) #inheritng the read_line_range and storing it into the String variable
    newL = String.split("\n") #splitting the string where the '\n' appears so that the new string is split into different lines for different words/clues
    counter = ran[0] #the counter starts at the position of the first number of the list
    counter2 = 0 # initialising a counter
    while counter in range(ran[0], ran[1]+1): #creating a while loop that runs as long as the counter is within the range of the 'ran' list
      x = newL[counter2] #stores each line into the x variable
      l = x[0:] #this variable is storing the x variable from the first letter onwards.
      y = l.split(",") #splitting the 'l' variable where a ',' appears in order to distinguish each word
      self.dictionary1[y[0]] = y[1:] # storing the first word of each line of the 'y' variable into the dictionary as a key and storing the rest of the words as values.
      counter += 1 #incrementing both counters
      counter2 += 1
    return self.dictionary1 # returning the new dictionary