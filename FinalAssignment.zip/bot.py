#https://repl.it/@JosephDHiggins/FinalAssignment#bot.py
#https://repl.it/join/hrklwlxj-josephdhiggins
from filemanager import *
#Method2
class Bot: #creating the class

  def __init__(self, nn, dict1): #using the __init__ function to assign values for the words and the robots nickname
    self.Botname = nn #used to assign a name to the bot
    self.key_word = [] #this opens a list where i can store and append key words.
    self.dictionary = dict1 #used to assign the key words to the dictionary
    for k in self.dictionary:
      self.key_word.append(k) #this loops through the key words of the dictionary and appends them to the list.
    self.nextWord = self.key_word[0] #this variable is used to retrieve each key word from the list
    self.value_clues = self.dictionary[self.nextWord]#this variable retrieves the values of each key word in the dictionary
    self.keyword_counter = 1 #setting the counter so it can iterate through the words and is to be used in the next_word() method
    self.valueclue_counter = 1 #setting the counter so it can iterate through the values and is to be used in the next_clue() method.
    self.nextClue = self.value_clues[self.valueclue_counter] #this variable iterates through the values with the counter so that it returns a different clue each time.
    self.answer = True #setting the answer to true to allow for the user to get the next word when they guess correctly
    self.closing_statement = "" #this is defining the closing statement as a string for the end of the program
    self.score_counter = 0

  def draw(self):
    print("================\n================\n================\n  ()\n -[]-\n  /\  \n") #this method returns an image of the robot to the user

  def get_bot(self):
    return self.Botname # this method returns the name of the new bot name if the user assigns a new name for the bot

  def set_bot(self, newbot):
    if newbot != self.Botname:
      self.Botname = newbot #this method allows the user to set a new name for the bot as long as it doesnt match the existing Bot Name

  def initial_greeting(self, player_name):
    self.draw()
    player_input = input("Hello " + player_name + ", Welcome to %s's Guessing Game. \n The aim of this game is to guess the words that have been selected for you to guess. I will present you with a clue and you have to guess what the word is.\n If you get the word right you will proceed to the second word and so on. If you get a word wrong, you will be presented with the second clue. You will get 5 clues and therefore 5 attempts to guess each word. \n Would you like to play? (y/n): " % self.Botname)
    return player_input #this method introduces the user to the game by saying its name and telling the user what the name of the bot is. It then asks the user if he/she wishes to proceed and returns the answer of the user.



class GuessingBot(Bot):

  def __init__(self, nn, dict1):
    super().__init__(nn, dict1)


  def draw(self):
    super().draw()


  def initial_greeting(self, player_name):
    original = super().initial_greeting(player_name)
    return original


  def respond_to_gameplay(self, response):  
    if response == "y" or response == "yes":
      pass #if the user responds with 'y', nothing will happen and the game will carry on.
    if response == "n" or response == "no":
      print("Okay, sorry to hear that.")
      pass #if the user answers 'n' then it will print a message that informs the user that the game will close.
    if response != "n" and response != "no" and response != "y" and response != "yes":
      print("Your command was not recognised")
      pass #if the user replies with an unknown command the game will tell the user that their input was not recognised


  def clue(self):
    super().draw()
    print("Your first clue for Word %i is: %s" % (self.keyword_counter, self.value_clues[0])) #this method displays the first clue of each word to the user. the word counter lets the user know what word they are on and then tells the user what the first clue of that word is.

  def guess(self, key_word):
    if key_word.upper() == self.nextWord.upper():
      self.answer = True
      print(" ================\n ================\n ================\n  ()\n -[]-\n  /\  \nCORRECT! CONGRATS YOU GOT IT RIGHT.") #if the user inputs a guess that is correct it is defined as true and a congrats message appears
      
    elif key_word == "new":
      print("A new set of words are being prepared. You need to select a new range in order to see these words.")

    elif key_word == "score":
      print("The scoring criteria has now changed so that the robot score increments by 10 every time you answer incorrectly.")


    else:
      self.answer = False #if the user doesnt input a correct guess then it is defined as False


  def next_clue(self):
    while self.valueclue_counter < len(self.value_clues): #looping through the clues while the clue counter is less than the amount of clues that were assigned to each word 
      self.nextClue = self.value_clues[self.valueclue_counter] #the current clue has been iterated by the clue counter meaning after each clue the user will be presented with a new clue
      self.valueclue_counter += 1 # this is the line where the iteration takes place
      print(" ================\n ================\n ================\n  ()\n -[]-\n  /\  \nThat is... WRONG!\nYour next clue is: %s" % self.nextClue) #this message presents the user with their next clue
      return self.nextClue


  def next_word(self):
    self.valueclue_counter = 1 #resets the clue counter to 1 for each new word.
    while self.keyword_counter < len(self.key_word): #loops through the key words as long as the counter is less than the amount of key words in the dictionary
      self.nextWord = self.key_word[self.keyword_counter] #the new word has been iterated by the keyword counter meaning there is a new word everytime the user guesses correctly
      self.value_clues = self.dictionary[self.nextWord] #updates the list of values for the new word
      self.keyword_counter += 1 #this line is used to iterate through the keywords
      return self.nextWord


  def add_score(self):
    print("The robot got a score of", self.score_counter) # printing a message that informs the user of the score of the robot

  def scoring_criteria(self):
    if self.answer == False:
      self.score_counter += 10 #incrementing the score counter by 10 instead of 1
    else:
      self.score_counter += 0
    return self.score_counter # returning the score counter 


  def get_ClosingStatement(self):
    return self.closing_statement # this method returns the closing statement

  def set_ClosingStatement(self):
    self.closing_statement = print("The game is now finished. Thanks for playing!!") #this method sets the closing statement that will appear when the game has finished.